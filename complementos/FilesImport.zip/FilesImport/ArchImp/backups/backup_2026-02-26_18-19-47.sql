-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: ecuasistencia2026_db
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_logs`
--

DROP TABLE IF EXISTS `activity_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `action` varchar(100) NOT NULL,
  `entity_type` varchar(50) DEFAULT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_date` (`created_at`),
  CONSTRAINT `activity_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_logs`
--

LOCK TABLES `activity_logs` WRITE;
/*!40000 ALTER TABLE `activity_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `activity_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendances`
--

DROP TABLE IF EXISTS `attendances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attendances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `school_year_id` int(11) NOT NULL,
  `shift_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `hour_period` varchar(20) DEFAULT NULL,
  `status` enum('presente','ausente','tardanza','justificado') NOT NULL,
  `observation` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `course_id` (`course_id`),
  KEY `subject_id` (`subject_id`),
  KEY `teacher_id` (`teacher_id`),
  KEY `school_year_id` (`school_year_id`),
  KEY `shift_id` (`shift_id`),
  KEY `idx_date` (`date`),
  KEY `idx_student` (`student_id`),
  CONSTRAINT `attendances_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`),
  CONSTRAINT `attendances_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`),
  CONSTRAINT `attendances_ibfk_3` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`),
  CONSTRAINT `attendances_ibfk_4` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`),
  CONSTRAINT `attendances_ibfk_5` FOREIGN KEY (`school_year_id`) REFERENCES `school_years` (`id`),
  CONSTRAINT `attendances_ibfk_6` FOREIGN KEY (`shift_id`) REFERENCES `shifts` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendances`
--

LOCK TABLES `attendances` WRITE;
/*!40000 ALTER TABLE `attendances` DISABLE KEYS */;
INSERT INTO `attendances` VALUES (1,54,16,2,52,1,1,'2026-02-25','3ra hora','presente','','2026-02-25 19:49:39','2026-02-25 19:49:39'),(2,55,16,2,52,1,1,'2026-02-25','3ra hora','presente','','2026-02-25 19:49:39','2026-02-25 19:49:39'),(3,54,16,2,52,1,1,'2026-02-24','3ra hora','presente','','2026-02-25 19:49:53','2026-02-25 19:52:15'),(4,55,16,2,52,1,1,'2026-02-24','3ra hora','justificado','','2026-02-25 19:49:53','2026-02-26 15:06:21'),(5,54,16,2,52,1,1,'2026-02-23','3ra hora','justificado','','2026-02-25 19:50:10','2026-02-26 15:06:42'),(6,55,16,2,52,1,1,'2026-02-23','3ra hora','presente','','2026-02-25 19:50:10','2026-02-25 19:50:35'),(7,54,16,2,52,1,1,'2026-02-26','2ra hora','justificado','','2026-02-26 14:47:13','2026-02-26 15:21:25'),(8,55,16,2,52,1,1,'2026-02-26','2ra hora','presente','','2026-02-26 14:47:13','2026-02-26 14:47:13'),(9,54,16,1,59,1,1,'2026-02-26','3ra hora','ausente','','2026-02-26 15:13:20','2026-02-26 15:22:31'),(10,55,16,1,59,1,1,'2026-02-26','3ra hora','ausente','','2026-02-26 15:13:20','2026-02-26 15:22:31'),(11,54,16,3,53,1,1,'2026-02-26','1ra hora','ausente','','2026-02-26 15:24:51','2026-02-26 15:24:51'),(12,55,16,3,53,1,1,'2026-02-26','1ra hora','ausente','','2026-02-26 15:24:51','2026-02-26 15:24:51');
/*!40000 ALTER TABLE `attendances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `class_schedule`
--

DROP TABLE IF EXISTS `class_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `class_schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `school_year_id` int(11) NOT NULL,
  `day_of_week` enum('lunes','martes','miercoles','jueves','viernes') NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `period_number` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `course_id` (`course_id`),
  KEY `subject_id` (`subject_id`),
  KEY `teacher_id` (`teacher_id`),
  KEY `school_year_id` (`school_year_id`),
  CONSTRAINT `class_schedule_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`),
  CONSTRAINT `class_schedule_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`),
  CONSTRAINT `class_schedule_ibfk_3` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`),
  CONSTRAINT `class_schedule_ibfk_4` FOREIGN KEY (`school_year_id`) REFERENCES `school_years` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `class_schedule`
--

LOCK TABLES `class_schedule` WRITE;
/*!40000 ALTER TABLE `class_schedule` DISABLE KEYS */;
INSERT INTO `class_schedule` VALUES (19,16,1,59,1,'jueves','00:00:00','00:00:00',3,'2026-02-25 19:47:56'),(20,16,3,53,1,'jueves','00:00:00','00:00:00',1,'2026-02-25 19:47:58'),(21,16,2,52,1,'jueves','00:00:00','00:00:00',2,'2026-02-25 19:48:00');
/*!40000 ALTER TABLE `class_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_students`
--

DROP TABLE IF EXISTS `course_students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course_students` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `school_year_id` int(11) NOT NULL,
  `enrollment_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_enrollment` (`student_id`,`course_id`,`school_year_id`),
  KEY `course_id` (`course_id`),
  KEY `school_year_id` (`school_year_id`),
  CONSTRAINT `course_students_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`),
  CONSTRAINT `course_students_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`),
  CONSTRAINT `course_students_ibfk_3` FOREIGN KEY (`school_year_id`) REFERENCES `school_years` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_students`
--

LOCK TABLES `course_students` WRITE;
/*!40000 ALTER TABLE `course_students` DISABLE KEYS */;
INSERT INTO `course_students` VALUES (8,54,16,1,'2026-02-25','2026-02-25 19:45:51'),(9,55,16,1,'2026-02-25','2026-02-25 19:45:51');
/*!40000 ALTER TABLE `course_students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_subjects`
--

DROP TABLE IF EXISTS `course_subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course_subjects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `hours_per_week` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_course_subject` (`course_id`,`subject_id`),
  KEY `cs_ibfk_2` (`subject_id`),
  CONSTRAINT `cs_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cs_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_subjects`
--

LOCK TABLES `course_subjects` WRITE;
/*!40000 ALTER TABLE `course_subjects` DISABLE KEYS */;
INSERT INTO `course_subjects` VALUES (33,16,1,'2026-02-25 19:38:38',1),(34,16,2,'2026-02-25 19:38:38',1),(35,16,3,'2026-02-25 19:38:38',1);
/*!40000 ALTER TABLE `course_subjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `courses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `institution_id` int(11) NOT NULL,
  `school_year_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `grade_level` varchar(50) DEFAULT NULL,
  `parallel` varchar(10) DEFAULT NULL,
  `shift_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `institution_id` (`institution_id`),
  KEY `school_year_id` (`school_year_id`),
  KEY `shift_id` (`shift_id`),
  CONSTRAINT `courses_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`),
  CONSTRAINT `courses_ibfk_2` FOREIGN KEY (`school_year_id`) REFERENCES `school_years` (`id`),
  CONSTRAINT `courses_ibfk_3` FOREIGN KEY (`shift_id`) REFERENCES `shifts` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courses`
--

LOCK TABLES `courses` WRITE;
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` VALUES (16,1,1,'Inicial 1 (0-3 años) \"A\" - Matutina','Inicial 1 (0-3 años)','A',1,'2026-02-25 19:38:38','2026-02-25 19:38:38');
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `institution_shifts`
--

DROP TABLE IF EXISTS `institution_shifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `institution_shifts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `institution_id` int(11) NOT NULL,
  `shift_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_institution_shift` (`institution_id`,`shift_id`),
  KEY `shift_id` (`shift_id`),
  CONSTRAINT `institution_shifts_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `institution_shifts_ibfk_2` FOREIGN KEY (`shift_id`) REFERENCES `shifts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `institution_shifts`
--

LOCK TABLES `institution_shifts` WRITE;
/*!40000 ALTER TABLE `institution_shifts` DISABLE KEYS */;
INSERT INTO `institution_shifts` VALUES (1,1,1,'2026-02-15 11:41:49'),(2,1,2,'2026-02-15 11:41:49');
/*!40000 ALTER TABLE `institution_shifts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `institutions`
--

DROP TABLE IF EXISTS `institutions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `institutions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` varchar(50) NOT NULL,
  `address` text DEFAULT NULL,
  `province` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `director_name` varchar(200) DEFAULT NULL,
  `amie_code` varchar(20) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `logo_path` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `working_days_list` varchar(100) DEFAULT '["lunes","martes","miercoles","jueves","viernes"]',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `institutions`
--

LOCK TABLES `institutions` WRITE;
/*!40000 ALTER TABLE `institutions` DISABLE KEYS */;
INSERT INTO `institutions` VALUES (1,'Unidad Educativa Pomasqui','UEP001','Av. Manuel Cordova Galarza 123, Quito, Ecuador','Pichincha','Quito','02-2351072','contacto@uep.edu.ec','MSc. Nombre Apellido','17h01988','https://www.uep.edu.ec','uploads/institution/logo_1_1771852565.jpg',1,'2026-02-11 23:56:53','2026-02-23 13:16:05','[\"lunes\",\"martes\",\"miercoles\",\"jueves\",\"viernes\"]');
/*!40000 ALTER TABLE `institutions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `justifications`
--

DROP TABLE IF EXISTS `justifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `justifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attendance_id` int(11) DEFAULT NULL,
  `date_from` date DEFAULT NULL,
  `date_to` date DEFAULT NULL,
  `working_days` int(11) DEFAULT NULL,
  `can_approve` enum('tutor','inspector','autoridad') NOT NULL DEFAULT 'inspector',
  `student_id` int(11) NOT NULL,
  `submitted_by` int(11) NOT NULL,
  `reason` text NOT NULL,
  `reason_type` varchar(100) DEFAULT NULL,
  `document_path` varchar(255) DEFAULT NULL,
  `status` enum('pendiente','aprobado','rechazado') DEFAULT 'pendiente',
  `reviewed_by` int(11) DEFAULT NULL,
  `review_notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `attendance_id` (`attendance_id`),
  KEY `submitted_by` (`submitted_by`),
  KEY `reviewed_by` (`reviewed_by`),
  KEY `idx_status` (`status`),
  KEY `idx_student` (`student_id`),
  CONSTRAINT `justifications_ibfk_1` FOREIGN KEY (`attendance_id`) REFERENCES `attendances` (`id`) ON DELETE CASCADE,
  CONSTRAINT `justifications_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`),
  CONSTRAINT `justifications_ibfk_3` FOREIGN KEY (`submitted_by`) REFERENCES `users` (`id`),
  CONSTRAINT `justifications_ibfk_4` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `justifications`
--

LOCK TABLES `justifications` WRITE;
/*!40000 ALTER TABLE `justifications` DISABLE KEYS */;
INSERT INTO `justifications` VALUES (1,5,'2026-02-23','2026-02-23',1,'tutor',54,54,'Cita médica o examen','Cita médica o examen','uploads/justifications/699f545922f58.png','aprobado',56,'ok','2026-02-25 19:58:17','2026-02-26 15:06:42'),(2,4,'2026-02-24','2026-02-24',1,'tutor',55,55,'Causas climáticas','Causas climáticas','uploads/justifications/69a05d17baf64.png','aprobado',52,'Ok','2026-02-26 14:47:51','2026-02-26 15:06:21'),(3,7,'2026-02-26','2026-02-26',1,'tutor',54,54,'Trámites legales / judiciales','Trámites legales / judiciales','uploads/justifications/69a0634f87fc6.png','aprobado',56,'','2026-02-26 15:14:23','2026-02-26 15:21:31'),(4,9,'2026-02-26','2026-02-26',1,'tutor',54,54,'Evento deportivo o académico oficial','Evento deportivo o académico oficial','uploads/justifications/69a06379a78b5.jpg','aprobado',59,'','2026-02-26 15:15:05','2026-02-26 15:21:25'),(5,10,'2026-02-26','2026-02-26',1,'tutor',55,55,'Trámites legales / judiciales','Trámites legales / judiciales','uploads/justifications/69a0638c70ba4.png','aprobado',56,'','2026-02-26 15:15:24','2026-02-26 15:21:18'),(6,12,'2026-02-26','2026-02-26',1,'tutor',55,55,'Causas climáticas','Causas climáticas','uploads/justifications/69a065e188e76.jpg','pendiente',NULL,NULL,'2026-02-26 15:25:21','2026-02-26 15:25:21'),(7,11,'2026-02-26','2026-02-26',1,'tutor',54,54,'xdfdfsad','Otro','uploads/justifications/69a0666defe34.jpg','pendiente',NULL,NULL,'2026-02-26 15:27:41','2026-02-26 15:27:41');
/*!40000 ALTER TABLE `justifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `link_requests`
--

DROP TABLE IF EXISTS `link_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `link_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `representative_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `relationship` varchar(50) NOT NULL,
  `message` text DEFAULT NULL,
  `status` enum('pendiente','aprobado','rechazado') NOT NULL DEFAULT 'pendiente',
  `reviewed_by` int(11) DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `review_notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_request` (`representative_id`,`student_id`),
  KEY `lr_stu_fk` (`student_id`),
  KEY `lr_rev_fk` (`reviewed_by`),
  CONSTRAINT `lr_rep_fk` FOREIGN KEY (`representative_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `lr_rev_fk` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `lr_stu_fk` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `link_requests`
--

LOCK TABLES `link_requests` WRITE;
/*!40000 ALTER TABLE `link_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `link_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` enum('info','warning','success','danger') DEFAULT 'info',
  `link` varchar(255) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_read` (`user_id`,`is_read`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (1,54,'📅 Ausencia registrada','Se registró una ausencia el 24/02/2026 en Expresión y Comunicación. Puedes justificarla.','','?action=my_attendance',0,'2026-02-25 19:49:53'),(2,55,'📅 Ausencia registrada','Se registró una ausencia el 24/02/2026 en Expresión y Comunicación. Puedes justificarla.','','?action=my_attendance',0,'2026-02-25 19:49:53'),(3,54,'📅 Ausencia registrada','Se registró una ausencia el 23/02/2026 en Expresión y Comunicación. Puedes justificarla.','','?action=my_attendance',0,'2026-02-25 19:50:10'),(4,54,'📅 Ausencia registrada','Se registró una ausencia el 23/02/2026 en Expresión y Comunicación. Puedes justificarla.','','?action=my_attendance',0,'2026-02-25 19:50:35'),(5,55,'📅 Ausencia registrada','Se registró una ausencia el 24/02/2026 en Expresión y Comunicación. Puedes justificarla.','','?action=my_attendance',0,'2026-02-25 19:52:15'),(6,52,'📝 Justificación pendiente (tutor)','Un estudiante de tu curso necesita justificación por 1 día(s).','info','?action=tutor_pending_justifications',1,'2026-02-25 19:58:17'),(7,54,'📅 Ausencia registrada','Se registró una ausencia el 26/02/2026 en Expresión y Comunicación. Puedes justificarla.','','?action=my_attendance',0,'2026-02-26 14:47:13'),(8,52,'📝 Justificación pendiente (tutor)','Un estudiante de tu curso necesita justificación por 1 día(s).','info','?action=tutor_pending_justifications',1,'2026-02-26 14:47:51'),(9,55,'✅ Justificación aprobada','Tu justificación fue aprobada. Nota: Ok','success','?action=my_justifications',0,'2026-02-26 15:06:21'),(10,54,'✅ Justificación aprobada','Tu justificación fue aprobada. Nota: ok','success','?action=my_justifications',0,'2026-02-26 15:06:42'),(11,54,'📅 Ausencia registrada','Se registró una ausencia el 26/02/2026 en Desarrollo Personal y Social. Puedes justificarla.','','?action=my_attendance',0,'2026-02-26 15:13:20'),(12,55,'📅 Ausencia registrada','Se registró una ausencia el 26/02/2026 en Desarrollo Personal y Social. Puedes justificarla.','','?action=my_attendance',0,'2026-02-26 15:13:20'),(13,52,'📝 Justificación pendiente (tutor)','Un estudiante de tu curso necesita justificación por 1 día(s).','info','?action=tutor_pending_justifications',0,'2026-02-26 15:14:23'),(14,52,'📝 Justificación pendiente (tutor)','Un estudiante de tu curso necesita justificación por 1 día(s).','info','?action=tutor_pending_justifications',0,'2026-02-26 15:15:05'),(15,52,'📝 Justificación pendiente (tutor)','Un estudiante de tu curso necesita justificación por 1 día(s).','info','?action=tutor_pending_justifications',0,'2026-02-26 15:15:24'),(16,55,'✅ Justificación aprobada','Tu justificación fue aprobada.','success','?action=my_justifications',0,'2026-02-26 15:21:18'),(17,54,'✅ Justificación aprobada','Tu justificación fue aprobada.','success','?action=my_justifications',0,'2026-02-26 15:21:25'),(18,54,'✅ Justificación aprobada','Tu justificación fue aprobada.','success','?action=my_justifications',0,'2026-02-26 15:21:31'),(19,54,'📅 Ausencia registrada','Se registró una ausencia el 26/02/2026 en Desarrollo Personal y Social. Puedes justificarla.','','?action=my_attendance',0,'2026-02-26 15:22:31'),(20,55,'📅 Ausencia registrada','Se registró una ausencia el 26/02/2026 en Desarrollo Personal y Social. Puedes justificarla.','','?action=my_attendance',0,'2026-02-26 15:22:31'),(21,54,'📅 Ausencia registrada','Se registró una ausencia el 26/02/2026 en Relación con el Entorno Natural y Cultural. Puedes justificarla.','','?action=my_attendance',0,'2026-02-26 15:24:51'),(22,55,'📅 Ausencia registrada','Se registró una ausencia el 26/02/2026 en Relación con el Entorno Natural y Cultural. Puedes justificarla.','','?action=my_attendance',0,'2026-02-26 15:24:51'),(23,52,'📝 Justificación pendiente (tutor)','Un estudiante de tu curso necesita justificación por 1 día(s).','info','?action=tutor_pending_justifications',0,'2026-02-26 15:25:21'),(24,52,'📝 Justificación pendiente (tutor)','Un estudiante de tu curso necesita justificación por 1 día(s).','info','?action=tutor_pending_justifications',0,'2026-02-26 15:27:41');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_type` varchar(50) NOT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `permissions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `representatives`
--

DROP TABLE IF EXISTS `representatives`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `representatives` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `representative_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `relationship` varchar(50) DEFAULT NULL,
  `is_primary` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_rep_student` (`representative_id`,`student_id`),
  KEY `student_id` (`student_id`),
  CONSTRAINT `representatives_ibfk_1` FOREIGN KEY (`representative_id`) REFERENCES `users` (`id`),
  CONSTRAINT `representatives_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `representatives`
--

LOCK TABLES `representatives` WRITE;
/*!40000 ALTER TABLE `representatives` DISABLE KEYS */;
INSERT INTO `representatives` VALUES (6,57,54,'Madre',1,'2026-02-25 19:46:01'),(7,58,55,'Madre',1,'2026-02-25 19:46:10');
/*!40000 ALTER TABLE `representatives` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'docente','Profesor de la institución','2026-02-11 23:56:54','2026-02-11 23:56:54'),(2,'estudiante','Estudiante activo','2026-02-11 23:56:54','2026-02-11 23:56:54'),(3,'inspector','Inspector de disciplina','2026-02-11 23:56:54','2026-02-11 23:56:54'),(4,'autoridad','Autoridad institucional','2026-02-11 23:56:54','2026-02-11 23:56:54'),(5,'representante','Representante legal de estudiante','2026-02-11 23:56:54','2026-02-11 23:56:54');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `school_years`
--

DROP TABLE IF EXISTS `school_years`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `school_years` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `institution_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `is_active` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `school_years_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `school_years`
--

LOCK TABLES `school_years` WRITE;
/*!40000 ALTER TABLE `school_years` DISABLE KEYS */;
INSERT INTO `school_years` VALUES (1,1,'2025-2026','2025-09-01','2026-07-30',1,'2026-02-20 13:42:21','2026-02-23 16:49:15');
/*!40000 ALTER TABLE `school_years` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shifts`
--

DROP TABLE IF EXISTS `shifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shifts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shifts`
--

LOCK TABLES `shifts` WRITE;
/*!40000 ALTER TABLE `shifts` DISABLE KEYS */;
INSERT INTO `shifts` VALUES (1,'matutina','2026-02-11 23:56:54'),(2,'vespertina','2026-02-11 23:56:54'),(3,'nocturna','2026-02-11 23:56:54');
/*!40000 ALTER TABLE `shifts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subjects`
--

DROP TABLE IF EXISTS `subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subjects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `institution_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `code` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `subjects_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subjects`
--

LOCK TABLES `subjects` WRITE;
/*!40000 ALTER TABLE `subjects` DISABLE KEYS */;
INSERT INTO `subjects` VALUES (1,1,'Desarrollo Personal y Social','','2026-02-20 14:42:59','2026-02-20 14:42:59'),(2,1,'Expresión y Comunicación','','2026-02-20 14:42:59','2026-02-20 14:42:59'),(3,1,'Relación con el Entorno Natural y Cultural','','2026-02-20 14:42:59','2026-02-20 14:42:59'),(4,1,'mate','MAT','2026-02-23 17:17:02','2026-02-23 17:17:02'),(5,1,'Lengua','LEN','2026-02-23 17:20:18','2026-02-23 17:20:18');
/*!40000 ALTER TABLE `subjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teacher_assignments`
--

DROP TABLE IF EXISTS `teacher_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teacher_assignments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `school_year_id` int(11) NOT NULL,
  `is_tutor` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `teacher_id` (`teacher_id`),
  KEY `course_id` (`course_id`),
  KEY `subject_id` (`subject_id`),
  KEY `school_year_id` (`school_year_id`),
  CONSTRAINT `teacher_assignments_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`),
  CONSTRAINT `teacher_assignments_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`),
  CONSTRAINT `teacher_assignments_ibfk_3` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`),
  CONSTRAINT `teacher_assignments_ibfk_4` FOREIGN KEY (`school_year_id`) REFERENCES `school_years` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teacher_assignments`
--

LOCK TABLES `teacher_assignments` WRITE;
/*!40000 ALTER TABLE `teacher_assignments` DISABLE KEYS */;
INSERT INTO `teacher_assignments` VALUES (11,59,16,1,1,0,'2026-02-25 19:47:43'),(12,52,16,2,1,1,'2026-02-25 19:47:48'),(13,53,16,3,1,0,'2026-02-25 19:47:52'),(14,52,16,2,1,0,'2026-02-26 14:46:50');
/*!40000 ALTER TABLE `teacher_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `assigned_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_role` (`user_id`,`role_id`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `user_roles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_roles_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_roles`
--

LOCK TABLES `user_roles` WRITE;
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
INSERT INTO `user_roles` VALUES (1,1,4,'2026-02-19 17:49:20'),(2,1,1,'2026-02-19 17:49:20'),(3,1,2,'2026-02-19 17:49:20'),(4,1,3,'2026-02-19 17:49:20'),(5,1,5,'2026-02-19 17:49:20'),(28,52,1,'2026-02-25 19:39:35'),(29,53,1,'2026-02-25 19:40:17'),(30,54,2,'2026-02-25 19:41:07'),(31,55,2,'2026-02-25 19:42:11'),(32,56,3,'2026-02-25 19:43:38'),(33,57,5,'2026-02-25 19:44:30'),(34,58,5,'2026-02-25 19:45:26'),(35,59,1,'2026-02-25 19:47:15'),(36,60,1,'2026-02-26 14:24:23'),(37,61,1,'2026-02-26 14:42:50');
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `institution_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(191) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `dni` varchar(20) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_expires` datetime DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `is_superadmin` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `dni` (`dni`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,1,'admin','admin@uep.edu.ec','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','Administrador','Sistema','1700000000','0999999999',NULL,NULL,1,1,'2026-02-11 23:56:54','2026-02-19 17:49:20'),(52,1,'victor','victor@uep.com','$2y$10$wmQH8.2yEIw8arrl18raXOPb2bp0DzQeyVnvIRKf1F.PI5blsBJCS','Victor','Rengel','1709613788','0998368685',NULL,NULL,1,0,'2026-02-25 19:39:35','2026-02-25 19:39:35'),(53,1,'pilar','pilar@uep.com','$2y$10$v3bWTXupUebcriFh1ZylRu8Bdoh4.Y4q7OwHNzxTTqycWhaon0F6S','Pilar','Serrano','1234567890','0998368685',NULL,NULL,1,0,'2026-02-25 19:40:11','2026-02-25 19:40:11'),(54,1,'Romina','romina@uep.com','$2y$10$CpcfGgXYSFJk0aVbht9LpOlOW9vHVb9C.vPwq9jf7hDDIN9MmU5Pm','Romina','Racines','1234567892',NULL,NULL,NULL,1,0,'2026-02-25 19:41:07','2026-02-25 19:42:29'),(55,1,'emilia','emilia@uep.com','$2y$10$WIFBPEsB7DPoH05574LkZupqo6pMr9q9sqMOaKotFE2RTWGYrpY3e','Emilia','Rengel','1234567891','0981145721',NULL,NULL,1,0,'2026-02-25 19:42:11','2026-02-25 19:42:11'),(56,1,'marco','marco@uep.com','$2y$10$XKRwq/5xOUIFthorbBspPeGpvBlvlpiYE3VAL0PYBoUr9M2v9Mqbq','Marco','Loachamin','1234567893','0981145722',NULL,NULL,1,0,'2026-02-25 19:43:38','2026-02-25 19:43:38'),(57,1,'rocio','rocio@uep.com','$2y$10$e0660tk.HSD75YwkI8eB0.RzN3YRRcF2nq0yVu.8wCiGDsdiEx/6O','Rocio','Rengel','1234567894',NULL,NULL,NULL,1,0,'2026-02-25 19:44:24','2026-02-25 19:44:24'),(58,1,'grace','grace@abc.com','$2y$10$QvLnNRjINAZIryJtl46BmuVBRi7Exj4R0KEjCSKkZWbXoFMKfKD72','Grace','Tito',NULL,NULL,NULL,NULL,1,0,'2026-02-25 19:45:26','2026-02-25 19:45:26'),(59,1,'mario','mario@abc.com','$2y$10$hyBbahMmiaofhP/qaTy9hePWBDHZoUEOurlsKDoLDOqSdjXpI6v9O','Mario','Muñoz',NULL,NULL,NULL,NULL,1,0,'2026-02-25 19:47:15','2026-02-25 19:47:15'),(60,1,'pamela',NULL,'$2y$10$AzE9jXPL19qck.axHZbCfuNrbiPUV6dN8WZVMgTJp5Fqvy.Sa7ne6','Pamela','Cortez',NULL,NULL,NULL,NULL,1,0,'2026-02-26 14:24:23','2026-02-26 14:24:23'),(61,1,'sandra',NULL,'$2y$10$KvxxLmMYRAbsPWEbogxicu.QqEh/gWVl2cPfi3IAIp9Oxptc4wG3K','Sandra','Flores',NULL,NULL,NULL,NULL,1,0,'2026-02-26 14:42:50','2026-02-26 14:42:50');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-26 18:19:47
