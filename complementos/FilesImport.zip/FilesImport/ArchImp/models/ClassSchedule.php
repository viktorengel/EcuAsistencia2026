<?php
class ClassSchedule {
    private $db;

    public function __construct($database) {
        $this->db = $database->connect();
    }

    public function create($data) {
        // Verificar si ya existe una clase en ese horario
        $checksql = 'SELECT s.name as subject_name,
                            COALESCE(CONCAT(u.last_name, " ", u.first_name), "Sin docente") as teacher_name
                     FROM class_schedule cs
                     INNER JOIN subjects s ON cs.subject_id = s.id
                     LEFT JOIN users u ON cs.teacher_id = u.id
                     WHERE cs.course_id = :course_id
                       AND cs.day_of_week = :day_of_week
                       AND cs.period_number = :period_number
                       AND cs.school_year_id = :school_year_id';

        $checkStmt = $this->db->prepare($checksql);
        $checkStmt->execute([
            'course_id' => $data['course_id'],
            'day_of_week' => $data['day_of_week'],
            'period_number' => $data['period_number'],
            'school_year_id' => $data['school_year_id']
        ]);

        $existing = $checkStmt->fetch();

        if ($existing) {
            return [
                'success' => false,
                'message' => 'Ya existe ' . $existing['subject_name'] . ' con ' . $existing['teacher_name'] . ' en este horario'
            ];
        }

        // SOLUCIÓN: Si teacher_id está vacío, usar NULL
        $teacherId = !empty($data['teacher_id']) ? $data['teacher_id'] : null;

        // Calcular start_time / end_time según periodo (45 min c/u, inicio 07:00)
        $periodMinutes = [
            1 => ['07:00', '07:45'], 2 => ['07:45', '08:30'],
            3 => ['08:30', '09:15'], 4 => ['09:15', '10:00'],
            5 => ['10:15', '11:00'], 6 => ['11:00', '11:45'],
            7 => ['11:45', '12:30'], 8 => ['12:30', '13:15'],
        ];
        $pn = (int)$data['period_number'];
        $startTime = $periodMinutes[$pn][0] ?? '07:00';
        $endTime   = $periodMinutes[$pn][1] ?? '07:45';

        // Verificar si la tabla tiene columnas start_time/end_time
        try {
            $cols = $this->db->query("SHOW COLUMNS FROM class_schedule LIKE 'start_time'")->fetchAll();
            $hasTime = count($cols) > 0;
        } catch (Exception $e) {
            $hasTime = false;
        }

        if ($hasTime) {
            $sql = 'INSERT INTO class_schedule
                    (course_id, subject_id, teacher_id, school_year_id, day_of_week, period_number, start_time, end_time)
                    VALUES (:course_id, :subject_id, :teacher_id, :school_year_id, :day_of_week, :period_number, :start_time, :end_time)';
            $stmt = $this->db->prepare($sql);
            $result = $stmt->execute([
                'course_id'     => $data['course_id'],
                'subject_id'    => $data['subject_id'],
                'teacher_id'    => $teacherId,
                'school_year_id'=> $data['school_year_id'],
                'day_of_week'   => $data['day_of_week'],
                'period_number' => $data['period_number'],
                'start_time'    => $startTime,
                'end_time'      => $endTime,
            ]);
        } else {
            $sql = 'INSERT INTO class_schedule
                    (course_id, subject_id, teacher_id, school_year_id, day_of_week, period_number)
                    VALUES (:course_id, :subject_id, :teacher_id, :school_year_id, :day_of_week, :period_number)';
            $stmt = $this->db->prepare($sql);
            $result = $stmt->execute([
                'course_id'     => $data['course_id'],
                'subject_id'    => $data['subject_id'],
                'teacher_id'    => $teacherId,
                'school_year_id'=> $data['school_year_id'],
                'day_of_week'   => $data['day_of_week'],
                'period_number' => $data['period_number'],
            ]);
        }

        return [
            'success' => $result,
            'message' => 'Clase agregada correctamente'
        ];
    }

    public function getByCourse($courseId, $schoolYearId) {
        $sql = 'SELECT cs.*,
                    s.name as subject_name,
                    -- Siempre obtener el docente actual de teacher_assignments
                    COALESCE(
                        (SELECT CONCAT(u2.last_name, " ", u2.first_name)
                            FROM teacher_assignments ta2
                            INNER JOIN users u2 ON ta2.teacher_id = u2.id
                            WHERE ta2.course_id = cs.course_id 
                            AND ta2.subject_id = cs.subject_id
                            AND ta2.school_year_id = cs.school_year_id
                            AND ta2.is_tutor = 0
                            LIMIT 1),
                        "Sin docente"
                    ) as teacher_name,
                    -- Traer también el ID del docente actual
                    (SELECT teacher_id
                        FROM teacher_assignments ta3
                        WHERE ta3.course_id = cs.course_id 
                        AND ta3.subject_id = cs.subject_id
                        AND ta3.school_year_id = cs.school_year_id
                        AND ta3.is_tutor = 0
                        LIMIT 1) as current_teacher_id
                FROM class_schedule cs
                INNER JOIN subjects s ON cs.subject_id = s.id
                WHERE cs.course_id = :course_id
                AND cs.school_year_id = :school_year_id
                ORDER BY cs.day_of_week, cs.period_number';

        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            'course_id' => $courseId,
            'school_year_id' => $schoolYearId
        ]);
        return $stmt->fetchAll();
    }

    public function getTeacherScheduleToday($teacherId, $schoolYearId) {
        $dayName = $this->getCurrentDayName();

        $sql = 'SELECT cs.*,
                       c.name as course_name,
                       c.grade_level,
                       s.name as subject_name
                FROM class_schedule cs
                INNER JOIN courses c ON cs.course_id = c.id
                INNER JOIN subjects s ON cs.subject_id = s.id
                WHERE cs.teacher_id = :teacher_id
                  AND cs.school_year_id = :school_year_id
                  AND cs.day_of_week = :day_of_week
                ORDER BY cs.period_number';

        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            'teacher_id' => $teacherId,
            'school_year_id' => $schoolYearId,
            'day_of_week' => $dayName
        ]);
        return $stmt->fetchAll();
    }

    public function delete($id) {
        $sql = "DELETE FROM class_schedule WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute(['id' => $id]);
    }

    private function getCurrentDayName() {
        // Forzar zona horaria Ecuador
        $tz = new DateTimeZone('America/Guayaquil');
        $now = new DateTime('now', $tz);
        $dayNumber = (int)$now->format('N'); // 1=Lunes, 7=Domingo

        $days = [
            1 => 'lunes',
            2 => 'martes',
            3 => 'miercoles',
            4 => 'jueves',
            5 => 'viernes',
            6 => 'sabado'
        ];

        return $days[$dayNumber] ?? 'lunes';
    }
}